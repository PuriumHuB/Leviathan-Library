-- Leviathan UI — Section element
-- Reworked BoxBorder: glowing gradient accent border
-- All original APIs preserved

local Creator = require("../modules/Creator")
local New = Creator.New
local Tween = Creator.Tween

local Element = {}

function Element:New(Config)
	local Section = {
		__type = "Section",
		Title = Config.Title or "Section",
		Desc = Config.Desc,
		Icon = Config.Icon,
		IconThemed = Config.IconThemed,
		TextXAlignment = Config.TextXAlignment or "Left",
		TextSize = Config.TextSize or 19,
		DescTextSize = Config.DescTextSize or 16,
		Box = Config.Box or false,
		BoxBorder = Config.BoxBorder or false,
		FontWeight = Config.FontWeight or Enum.FontWeight.SemiBold,
		DescFontWeight = Config.DescFontWeight or Enum.FontWeight.Medium,
		TextTransparency = Config.TextTransparency or 0.05,
		DescTextTransparency = Config.DescTextTransparency or 0.4,
		Opened = Config.Opened or false,
		UIElements = {},

		HeaderSize = 48,
		IconSize = 20,
		Padding = 10,

		Elements = {},
		Expandable = false,
	}

	local Icon

	function Section:SetIcon(i)
		Section.Icon = i or nil
		if Icon then Icon:Destroy() end
		if i then
			Icon = Creator.Image(
				i,
				i .. ":" .. Section.Title,
				0,
				Config.Window.Folder,
				Section.__type,
				true,
				Section.IconThemed,
				"SectionIcon"
			)
			Icon.Size = UDim2.new(0, Section.IconSize, 0, Section.IconSize)
		end
	end

	local ChevronIconFrame = New("Frame", {
		Size = UDim2.new(0, Section.IconSize, 0, Section.IconSize),
		BackgroundTransparency = 1,
		Visible = false,
	}, {
		New("ImageLabel", {
			Size = UDim2.new(1, 0, 1, 0),
			BackgroundTransparency = 1,
			Image = Creator.Icon("chevron-down")[1],
			ImageRectSize = Creator.Icon("chevron-down")[2].ImageRectSize,
			ImageRectOffset = Creator.Icon("chevron-down")[2].ImageRectPosition,
			ThemeTag = {
				ImageTransparency = "SectionExpandIconTransparency",
				ImageColor3 = "SectionExpandIcon",
			},
		}),
	})

	if Section.Icon then Section:SetIcon(Section.Icon) end

	local TitleContainer = New("Frame", {
		Size = UDim2.new(1, 0, 1, 0),
		BackgroundTransparency = 1,
	}, {
		New("UIListLayout", {
			FillDirection = "Vertical",
			HorizontalAlignment = Section.TextXAlignment,
			VerticalAlignment = "Center",
			Padding = UDim.new(0, 4),
		}),
	})

	local TitleFrame, DescFrame

	local function createTitle(Text, Type)
		return New("TextLabel", {
			BackgroundTransparency = 1,
			TextXAlignment = Section.TextXAlignment,
			AutomaticSize = "Y",
			TextSize = Type == "Title" and Section.TextSize or Section.DescTextSize,
			TextTransparency = Type == "Title" and Section.TextTransparency or Section.DescTextTransparency,
			ThemeTag = { TextColor3 = "Text" },
			FontFace = Font.new(Creator.Font, Type == "Title" and Section.FontWeight or Section.DescFontWeight),
			Text = Text,
			Size = UDim2.new(1, 0, 0, 0),
			TextWrapped = true,
			Parent = TitleContainer,
		})
	end

	TitleFrame = createTitle(Section.Title, "Title")
	if Section.Desc then DescFrame = createTitle(Section.Desc, "Desc") end

	local function UpdateTitleSize()
		local offset = 0
		if Icon then offset = offset - (Section.IconSize + 8) end
		if ChevronIconFrame.Visible then offset = offset - (Section.IconSize + 8) end
		TitleContainer.Size = UDim2.new(1, offset, 0, 0)
	end

	-- ── BoxBorder rework ──────────────────────────────────────────
	-- Instead of a flat white outline, we build a gradient glow ring
	-- that picks up the theme's Button colour.
	-- The ring is a SquircleOutline with a UIGradient applied.
	-- When Box = true and BoxBorder = true, this replaces the old border.

	local GlowBorder
	if Section.Box and Section.BoxBorder then
		GlowBorder = Creator.NewRoundFrame(Config.Window.ElementConfig.UICorner - 1, "SquircleOutline", {
			Size              = UDim2.new(1, 0, 1, 0),
			ThemeTag          = { ImageColor3 = "SectionBoxBorder" },
			ImageTransparency = 0.50,   -- visible glow
			Name              = "GlowBorder",
			ZIndex            = 2,
		}, {
			-- Gradient makes it look like light hitting the edge
			New("UIGradient", {
				Rotation = 135,
				Transparency = NumberSequence.new({
					NumberSequenceKeypoint.new(0,   0.0),
					NumberSequenceKeypoint.new(0.3, 0.5),
					NumberSequenceKeypoint.new(0.7, 0.5),
					NumberSequenceKeypoint.new(1,   0.0),
				}),
			}),
		})
	end

	local Main = Creator.NewRoundFrame(Config.Window.ElementConfig.UICorner, "Squircle", {
		Size = UDim2.new(1, 0, 0, 0),
		BackgroundTransparency = 1,
		Parent = Config.Parent,
		AutomaticSize = "Y",
		ThemeTag = {
			ImageTransparency = Section.Box and "SectionBoxBackgroundTransparency" or nil,
			ImageColor3 = "SectionBoxBackground",
		},
		ImageTransparency = not Section.Box and 1 or nil,
	}, {
		Creator.NewRoundFrame(Config.Window.ElementConfig.UICorner - 1, "SquircleOutline", {
			Size = UDim2.new(1, 0, 1, 0),
			ThemeTag = {
				ImageColor3 = "SectionBoxBorder",
			},
			-- base subtle border only when Box=true; BoxBorder adds the glow ring on top
			ImageTransparency = Section.Box and (not Section.BoxBorder and 0.92 or 0.94) or 1,
			Name = "Outline",
			ClipsDescendants = true,
		}, {
			New("TextButton", {
				Size = UDim2.new(1, 0, 0, Section.Expandable and 0 or (not DescFrame and Section.HeaderSize or 0)),
				BackgroundTransparency = 1,
				AutomaticSize = (not Section.Expandable or DescFrame) and "Y" or nil,
				Text = "",
				Name = "Top",
			}, {
				Section.Box and New("UIPadding", {
					PaddingTop    = UDim.new(0, Config.Window.ElementConfig.UIPadding + (Config.Window.NewElements and 4 or 0)),
					PaddingLeft   = UDim.new(0, Config.Window.ElementConfig.UIPadding + (Config.Window.NewElements and 4 or 0)),
					PaddingRight  = UDim.new(0, Config.Window.ElementConfig.UIPadding + (Config.Window.NewElements and 4 or 0)),
					PaddingBottom = UDim.new(0, Config.Window.ElementConfig.UIPadding + (Config.Window.NewElements and 4 or 0)),
				}) or nil,
				Icon,
				TitleContainer,
				New("UIListLayout", {
					Padding = UDim.new(0, 8),
					FillDirection = "Horizontal",
					VerticalAlignment = "Center",
					HorizontalAlignment = "Left",
				}),
				ChevronIconFrame,
			}),
			New("Frame", {
				BackgroundTransparency = 1,
				Size = UDim2.new(1, 0, 0, 0),
				AutomaticSize = "Y",
				Name = "Content",
				Visible = false,
				Position = UDim2.new(0, 0, 0, Section.HeaderSize + 10),
			}, {
				Section.Box and New("UIPadding", {
					PaddingLeft   = UDim.new(0, Config.Window.ElementConfig.UIPadding / 1.5),
					PaddingRight  = UDim.new(0, Config.Window.ElementConfig.UIPadding / 1.5),
					PaddingBottom = UDim.new(0, Config.Window.ElementConfig.UIPadding / 1.5),
				}) or nil,
				New("UIListLayout", {
					FillDirection = "Vertical",
					Padding = UDim.new(0, Config.Tab.Gap),
					VerticalAlignment = "Top",
				}),
			}),
		}),
		GlowBorder,   -- sits on top of the Outline ring when BoxBorder = true
	})

	Section.ElementFrame = Main

	Main.Outline.Top:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
		Main.Outline.Content.Position = UDim2.new(0, 0, 0, (Main.Outline.Top.AbsoluteSize.Y / Config.UIScale) + 10)
		if Section.Opened then
			Section:Open(true)
		else
			Section.Close(true)
		end
	end)

	local ElementsModule = Config.ElementsModule
	ElementsModule.Load(
		Section,
		Main.Outline.Content,
		ElementsModule.Elements,
		Config.Window,
		Config.WindUI,
		function()
			if not Section.Expandable then
				Section.Expandable = true
				ChevronIconFrame.Visible = true
				UpdateTitleSize()
			end
		end,
		ElementsModule,
		Config.UIScale,
		Config.Tab
	)

	UpdateTitleSize()

	function Section:SetTitle(Title)
		Section.Title = Title
		TitleFrame.Text = Title
	end

	function Section:SetDesc(Desc)
		Section.Desc = Desc
		if not DescFrame then DescFrame = createTitle(Desc, "Desc") end
		DescFrame.Text = Desc
	end

	function Section:Destroy()
		for _, element in next, Section.Elements do
			element:Destroy()
		end
		Main:Destroy()
	end

	function Section:Open(IsNotAnim)
		if Section.Expandable then
			Section.Opened = true
			local targetH = Main.Outline.Top.AbsoluteSize.Y / Config.UIScale
				+ (Main.Outline.Content.AbsoluteSize.Y / Config.UIScale)
				+ 10
			if IsNotAnim then
				Main.Size = UDim2.new(Main.Size.X.Scale, Main.Size.X.Offset, 0, targetH)
				ChevronIconFrame.ImageLabel.Rotation = 180
			else
				Tween(Main, 0.33, {
					Size = UDim2.new(Main.Size.X.Scale, Main.Size.X.Offset, 0, targetH),
				}, Enum.EasingStyle.Quint, Enum.EasingDirection.Out):Play()
				Tween(ChevronIconFrame.ImageLabel, 0.2, { Rotation = 180 },
					Enum.EasingStyle.Quint, Enum.EasingDirection.Out):Play()
			end
			-- Animate glow border brighter when expanded
			if GlowBorder then
				Tween(GlowBorder, 0.25, { ImageTransparency = 0.35 }):Play()
			end
		end
	end

	function Section:Close(IsNotAnim)
		if Section.Expandable then
			Section.Opened = false
			local targetH = Main.Outline.Top.AbsoluteSize.Y / Config.UIScale
			if IsNotAnim then
				Main.Size = UDim2.new(Main.Size.X.Scale, Main.Size.X.Offset, 0, targetH)
				ChevronIconFrame.ImageLabel.Rotation = 0
			else
				Tween(Main, 0.26, {
					Size = UDim2.new(Main.Size.X.Scale, Main.Size.X.Offset, 0, targetH),
				}, Enum.EasingStyle.Quint, Enum.EasingDirection.Out):Play()
				Tween(ChevronIconFrame.ImageLabel, 0.2, { Rotation = 0 },
					Enum.EasingStyle.Quint, Enum.EasingDirection.Out):Play()
			end
			-- Dim glow border when collapsed
			if GlowBorder then
				Tween(GlowBorder, 0.25, { ImageTransparency = 0.55 }):Play()
			end
		end
	end

	Creator.AddSignal(Main.Outline.Top.MouseButton1Click, function()
		if Section.Expandable then
			if Section.Opened then Section:Close() else Section:Open() end
		end
	end)

	Creator.AddSignal(Main.Outline.Content.UIListLayout:GetPropertyChangedSignal("AbsoluteContentSize"), function()
		if Section.Opened then Section:Open(true) else Section:Close(true) end
	end)

	task.defer(function()
		if Section.Expandable then
			Main.Size = UDim2.new(Main.Size.X.Scale, Main.Size.X.Offset, 0, Main.Outline.Top.AbsoluteSize.Y / Config.UIScale)
			Main.AutomaticSize = "None"
			Main.Outline.Top.Size = UDim2.new(1, 0, 0, (not DescFrame and Section.HeaderSize or 0))
			Main.Outline.Top.AutomaticSize = (not Section.Expandable or DescFrame) and "Y" or "None"
			Main.Outline.Content.Visible = true
		end
		if Section.Opened then Section:Open() else Section:Close(true) end
	end)

	return Section.__type, Section
end

return Element
